const grid = document.getElementById('grid');
const modal = document.getElementById('modal');
let activeCell = null; // Запоминаем, в какую ячейку добавляем блок

// Генерация 12 ячеек сетки при загрузке
for (let i = 0; i < 12; i++) {
    let cell = document.createElement('div');
    cell.className = 'cell empty';
    cell.innerHTML = '+';
    cell.onclick = () => { if (cell.classList.contains('empty')) openModal(cell); };
    grid.appendChild(cell);
}

function openModal(cell) {
    activeCell = cell;
    modal.classList.remove('hidden');
    modal.style.display = 'flex';
}

function closeModal() {
    modal.classList.add('hidden');
}

function addBlock() {
    const type = document.getElementById('bType').value;

    activeCell.classList.remove('empty');
    activeCell.innerHTML = '';
    activeCell.onclick = null; // Убираем реакцию на клик для самой ячейки

    // Добавляем кнопку подключения всем, кроме стрелок
    if (!type.startsWith('arr-')){
        let btn = document.createElement('button');
        btn.className = 'status-btn';
        btn.innerText = 'Не подключен';
        activeCell.appendChild(btn);
    }

    // Рендер внутренностей в зависимости от выбранного типа
    if (type === 'logic') {
        let el = document.createElement('div');
        el.className = 'logic';
        activeCell.appendChild(el);
    } 
    else if (type === 'scale') {
        activeCell.innerHTML += `
            <div class="scale">
                <input type="number" value="100">
                <div class="scale-bar"></div>
                <input type="number" value="0">
            </div>`;
    } 
    else if (type === 'number') {
        let el = document.createElement('div');
        el.className = 'num';
        el.innerText = '0';
        activeCell.appendChild(el);
    } 
    else if (type.startsWith('arr-')) {
        const arrows = { 'arr-up': '↑', 'arr-down': '↓', 'arr-left': '←', 'arr-right': '→' };
        activeCell.innerHTML += `<div class="arrow">${arrows[type]}</div>`;
    }
    closeModal();
}