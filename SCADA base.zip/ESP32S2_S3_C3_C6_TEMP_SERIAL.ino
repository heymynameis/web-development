#include "driver/temperature_sensor.h"

// Создаем дескриптор датчика
temperature_sensor_handle_t temp_handle = NULL;
// Настраиваем конфигурацию
temperature_sensor_config_t temp_sensor_config = TEMPERATURE_SENSOR_CONFIG_DEFAULT(10, 50);

void setup() {
    // Инициализация датчика
    temperature_sensor_install(&temp_sensor_config, &temp_handle);
    temperature_sensor_enable(temp_handle);

    Serial.begin(115200);
}

void loop() {
    // Считывание значения в градусах Цельсия
    float tsens_out;
    temperature_sensor_get_celsius(temp_handle, &tsens_out);
    Serial.write((uint8_t*)&tsens_out, 4);
    delay(1000);
}